# Verified UMBRA concept — 2026-09-07

Generated using Blender 4.5.7 on Apple Silicon. Preserves the supplied 1087 x 865 UMBRA v1.6.2 reference; this is a hardware concept, not an existing physical product.

Corrections to the downloaded generator:
- Hollow enclosure, gasket and display mounting frame.
- Display aperture, shaft openings and control-board clearance.
- Full-coverage display UVs and transparent display glass.
- Fastener slots follow their screws; lower-profile screw heads.
- Ordered separation keeps the main board below the control board, display, faceplate, caps and fasteners.
- Blender 4.5 action handling and NLA exports produce exactly Explode and Assemble, each with eight translation tracks.
- Correct overhead comparison camera and wider product framing.
- Mobile mesh decimation after modifiers.

See output/verified-export-report.json for counts measured from the final GLBs. The original UMBRA_stats.json records source geometry before evaluated modifiers, so its triangle estimates are not final export counts.

The local website uses these GLBs with native-scroll animation scrubbing, lazy loading and a simplified mobile export. Screenshot proportions and animation tracks are checked by tests/umbra-blender.spec.ts in the website project. Internal electronics and proposed physical measurements remain design assumptions.

Run the generator from this folder with:
/Applications/Blender.app/Contents/MacOS/Blender --background --python umbra_build.py
